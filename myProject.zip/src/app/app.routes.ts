// Import the Angular router types
import { Routes } from '@angular/router';

// Import the layout shell (navbar + footer wrapper)
import { ShellComponent } from './layout/shell/shell.component';

// Import the global 404 page
import { NotFoundComponent } from './core/not-found/not-found.component';

// Main app route configuration
export const appRoutes: Routes = [
  {
    // Root path uses Shell layout
    path: '',
    component: ShellComponent,

    // Child routes are lazy-loaded feature routes
    children: [
      {
        // Home page
        path: '',
        loadChildren: () =>
          import('./features/home/routes').then(m => m.HOME_ROUTES)
      },
      {
        // Product list + details
        path: 'products',
        loadChildren: () =>
          import('./features/products/routes').then(m => m.PRODUCTS_ROUTES)
      },
      {
        // Shopping cart
        path: 'cart',
        loadChildren: () =>
          import('./features/cart/routes').then(m => m.CART_ROUTES)
      },
      {
        // Auth (login/register)
        path: 'auth',
        loadChildren: () =>
          import('./features/auth/routes').then(m => m.AUTH_ROUTES)
      },
      {
        // User profile
        path: 'profile',
        loadChildren: () =>
          import('./features/profile/routes').then(m => m.PROFILE_ROUTES)
      }
    ]
  },

  // Wildcard route for 404 pages
  { path: '**', component: NotFoundComponent }
];
