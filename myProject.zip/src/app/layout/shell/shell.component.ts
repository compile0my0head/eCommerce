import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';          
import { NavbarComponent } from '../navbar/navbar.component';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [
    RouterOutlet,        // Provides <router-outlet>
    NavbarComponent,     // Provides <app-navbar>
    FooterComponent      // Provides <app-footer>
  ],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss']
})
export class ShellComponent {}
