import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent {
  isScrolledDown = false; // Tracks scroll direction
  lastScrollY = 0;        // Stores last scroll position

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const currentScroll = window.scrollY;
    this.isScrolledDown = currentScroll > this.lastScrollY && currentScroll > 50;
    this.lastScrollY = currentScroll;
  }
}
